<footer class="main-footer">
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-6">
      <p>Copyright &copy; <?=getyear() ?></p>
    </div>
    <div class="col-sm-6 text-right">
      <p><a href="" class="external">Nama Instansi atau organisasi</a></p>
      <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions and it helps me to run Bootstrapious. Thank you for understanding :)-->
    </div>
  </div>
</div>
</footer>
</div>
    <!-- JavaScript files-->
 
    <script src="<?php echo base_url('popper.min.js')?>"> </script>
    <script src="<?php echo base_url('theme/darkgreen/js/grasp_mobile_progress_circle-1.0.0.min.js')?>"></script>
    <script src="<?php echo base_url('j-query/jquery.cookie.js')?>"> </script>
    <script src="<?php echo base_url('theme/darkgreen/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')?>"></script>
    <!-- Main File-->
    <script src="<?php echo base_url('theme/darkgreen/js/front.js')?>"></script>
  </body>
</html>